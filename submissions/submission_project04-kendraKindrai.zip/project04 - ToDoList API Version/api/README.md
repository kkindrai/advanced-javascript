# How to start this API

- In this directory, run `nodemon index`
- Will be hosted on localhost:3000/api